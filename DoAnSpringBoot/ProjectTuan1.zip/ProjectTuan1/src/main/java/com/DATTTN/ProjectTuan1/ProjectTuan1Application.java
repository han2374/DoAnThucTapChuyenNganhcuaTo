package com.DATTTN.ProjectTuan1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectTuan1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectTuan1Application.class, args);
	}

}
